import logging
logger = logging.getLogger(__name__)


class FareCard:
    """
    Handles all card related transactions such as:
    Add balance
    Remove balance
    Get balance
    """
    def __init__(self):
        """Initial balance in card is 0"""
        self.balance = 0

    def credit_balance(self, amount):
        """
        Credit the card with given amount
        :param amount: amount to credit
        :return: None
        """
        self.balance = round(self.balance + amount, 2)
        logger.info("New balance: {}".format(self.balance))

    def debit_balance(self, amount):
        """
        Debit amount from Fare card
        :param amount: amount to debit
        :return: None
        """
        self.balance = round(self.balance - amount, 2)

    def get_balance(self):
        """
        Return current balance in card
        :return: current balance
        """
        return self.balance
