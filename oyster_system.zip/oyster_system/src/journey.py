from config import *


class Journey:
    def __init__(self):
        self.current_journey = {
            "start_zone": None,
            "end_zone": None
        }
        self.type = None

    def set_journey_type(self, _type):
        """
        Set journey type
        :param _type: Tube or Bus types of journey
        :return: None
        """
        self.type = _type

    def get_journey_type(self):
        """
        Return current journey type
        :return: journey type
        """
        return self.type

    def from_station(self, station_name, _type):
        """
        Set value of starting station/zone
        :param station_name: station from where journey begins
        :param _type: ride type
        :return: None
        """
        if _type is None or _type.lower() not in TRAVEL_MODES:
            raise RuntimeError("Travel mode {} not found".format(_type))

        self.current_journey['start_zone'] = station_name
        self.set_journey_type(_type)

    def to_station(self, station_name):
        """
        Set value for station where journey ends
        :param station_name: last station
        :return: None
        """
        self.current_journey["end_zone"] = station_name

    @staticmethod
    def get_cost_by_zones(start_zone, end_zone, total_zones_crossed):
        """
        Returns Cost of travel between start and end zone
        of journey.
        :param start_zone: Starting point of journey
        :param end_zone: Ending point of journey
        :param total_zones_crossed: went through total zones
        :return: Total Cost of Journey
        """
        is_zone_one_crossed = False
        if (len(start_zone) == 1 and 1 in start_zone) or \
                (len(end_zone) == 1 and 1 in end_zone):
            is_zone_one_crossed = True

        if total_zones_crossed == 1 and is_zone_one_crossed:
            return TRAVEL_ONLY_ZONE_ONE
        elif total_zones_crossed == 1 and not is_zone_one_crossed:
            return TRAVEL_ONE_ZONE_EXCEPT_ZONE_ONE
        elif total_zones_crossed == 2 and is_zone_one_crossed:
            return TRAVEL_TWO_ZONES_INCLUDING_ZONE_ONE
        elif total_zones_crossed == 2 and not is_zone_one_crossed:
            return TRAVEL_TWO_ZONES_EXCEPT_ZONE_ONE
        elif total_zones_crossed == 3:
            return MAXIMUM_COST
        return MAXIMUM_COST

    @staticmethod
    def get_zones_crossed(start_zone, end_zone):
        """
        Find total zones crossed between the start and
        end of journey
        :param end_zone: End zone
        :param start_zone: Start zone
        :return: total zones crossed by user
        """
        total_zones_crossed = 0
        for y in start_zone:
            for x in end_zone:
                total_zones_crossed = abs(y - x) + 1
                if total_zones_crossed == 1:
                    break
        return total_zones_crossed

    def get_journey_cost(self):
        """
        Estimate the cost of journey.
        :return: journey cost
        """
        start_zone = self.current_journey['start_zone'].get_zone()  # Get start zone
        end_zone = self.current_journey['end_zone'].get_zone()  # Get end zone
        total_zones_crossed = self.get_zones_crossed(start_zone, end_zone)
        cost = self.get_cost_by_zones(start_zone, end_zone, total_zones_crossed)
        return cost
