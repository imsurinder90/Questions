from src.journey import Journey
from src.station import Station
from config import *
import logging
logger = logging.getLogger(__name__)


class Oyster:
    def __init__(self):
        self.card = None
        self.journey = Journey()
        self.has_swipe_card = False

    def swipe_card(self, card):
        self.card = card
        self.has_swipe_card = True

    def recharge_card(self, amount):
        if not self.has_swipe_card:
            raise RuntimeError("Please swipe the card first")

        self.card.credit_balance(amount)

    def start_journey(self, station_name, travel_type):
        """
        Given the source station and travel type, the journey
        start and Oyster charges the maximum fare if travel by Tube.
        Bus journey is charged at same price.
        :param station_name: source station
        :param travel_type: mode of travel, default Tube
        :return: None
        """

        if not self.has_swipe_card:
            raise RuntimeError("Please swipe the card first")

        if self.card is not None and self.card.get_balance() < MINIMUM_BALANCE:
            raise RuntimeError(
                "Insufficient balance."
                "To travel Minimum balance should be {}".format(MINIMUM_BALANCE)
            )

        if travel_type is None or travel_type.lower() not in TRAVEL_MODES:
            raise RuntimeError("Travel mode {} not found".format(travel_type))

        logger.info("==" * 20)
        if travel_type is None or travel_type.lower() == "tube":
            logger.info("Starting {} Journey from {} ".format(travel_type, station_name))
            self.journey.from_station(Station.get_station_by_name(station_name), travel_type)
            logger.info("Charge with maximum fare {} - {} = {} ".format(
                self.card.balance, MAXIMUM_COST, round((self.card.balance - MAXIMUM_COST), 2))
            )
            self.card.debit_balance(MAXIMUM_COST)  # Oyster has charged maximum fare
        else:
            logger.info("Starting {} Journey from {} ".format(travel_type, station_name))
            logger.info("Deduct Bus Fare: {} - {} = {}".format(self.card.balance, BUS_COST, round((self.card.balance - BUS_COST), 2)))
            self.card.debit_balance(BUS_COST)
            logger.info("Current balance: {}\r\n".format(self.card.balance))

    def end_journey(self, station_name):
        """
        Now the journey ends, Card is credited with maximum balance
        and deducted journey cost from it.
        :param station_name: station where journey ends
        :return: None
        """

        if self.journey.current_journey['start_zone'] is None:
            raise RuntimeError("Start zone cannot be empty.")

        logger.info("Ending Journey to {} ".format(station_name))
        logger.info("Credit maximum fare: {} ".format(MAXIMUM_COST))
        self.card.credit_balance(MAXIMUM_COST)  # Credit the balance
        self.journey.to_station(Station.get_station_by_name(station_name))  # destination
        journey_cost = self.journey.get_journey_cost()  # get journey cost
        logger.info("Journey Cost: {} ".format(journey_cost))
        logger.info("Deducting Fare cost: {} - {} ".format(self.card.balance, journey_cost))
        self.card.debit_balance(journey_cost)  # debit journey cost from card
        logger.info("Current balance: {}\r\n".format(self.card.balance))
