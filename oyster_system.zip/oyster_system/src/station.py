import config


class Station:
    """
    Provides functionality for station and zones
    """

    def __init__(self, station, zone):
        self.station = station
        self.zone = zone

    def get_station(self):
        """Get station"""
        return self.station

    def get_zone(self):
        """Get zone"""
        return self.zone

    @classmethod
    def get_station_by_name(cls, station_name):
        """
        Get station by name. Raise exception if station name
        not found.
        """
        station = config.STATIONS_NAME.get(station_name, None)
        if station is None:
            raise RuntimeError("Station {} not found".format(station))
        return cls(station_name, station)
