from src.card import FareCard


class TestFareCard:

    def test_methods(self):
        """
        Test methods of class FareCard
        :return: None
        """
        cardObj = FareCard()
        assert cardObj.balance == 0

        cardObj.credit_balance(0.20)  # Credit balance
        assert cardObj.get_balance() == 0.20

        cardObj.debit_balance(0.10)  # Debit balance
        assert cardObj.get_balance() == 0.10

        assert cardObj.get_balance() == 0.10  # Check remaining balance
