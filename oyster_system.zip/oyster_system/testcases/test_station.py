from src.station import Station
import config


class TestStation:

    def test_methods(self):
        """
        Test methods of class Station
        :return: None
        """
        stationObj = Station.get_station_by_name("Hammersmith")
        assert stationObj.get_station() == "Hammersmith"
        assert stationObj.get_zone() == config.STATIONS_NAME.get("Hammersmith")
