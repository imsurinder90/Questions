import pytest
from src.oyster import Oyster
from src.card import FareCard


class TestOyster:

    def test_methods(self):
        """
        Test methods of class Station
        :return: None
        """
        card_obj = FareCard()
        oyster_obj = Oyster()

        # Scan fare card
        oyster_obj.swipe_card(card_obj)
        oyster_obj.recharge_card(30)

        # Test case 1 - Took Tube from Holborn to EarlsCourt
        oyster_obj.start_journey("Holborn", "Tube")
        oyster_obj.end_journey("EarlsCourt")
        assert oyster_obj.card.balance == 27.5

        # Test case 2 - Took Bus from EarlsCourt to Chelsea
        oyster_obj.start_journey("EarlsCourt", "Bus")
        assert oyster_obj.card.balance == 25.7

        # Test case 3 - Took Tube from EarlsCourt to Hammersmith
        oyster_obj.start_journey("EarlsCourt", "Tube")
        oyster_obj.end_journey("Hammersmith")
        assert oyster_obj.card.balance == 23.7

    # Negative test cases
    def test_did_not_swipe_card(self):
        oyster_obj = Oyster()

        # Scan fare card
        # oyster_obj.swipe_card(card_obj)
        with pytest.raises(RuntimeError):
            oyster_obj.recharge_card(30)

    def test_recharge_card_with_zero_balance(self):
        card_obj = FareCard()
        oyster_obj = Oyster()

        # Swipe fare card
        oyster_obj.swipe_card(card_obj)
        oyster_obj.recharge_card(0)
        with pytest.raises(RuntimeError):
            oyster_obj.start_journey("EarlsCourt", "Tube")

    def test_user_directly_ends_journey(self):
        card_obj = FareCard()
        oyster_obj = Oyster()

        # Scan fare card
        oyster_obj.swipe_card(card_obj)
        oyster_obj.recharge_card(30)
        with pytest.raises(RuntimeError):
            oyster_obj.end_journey("EarlsCourt")
