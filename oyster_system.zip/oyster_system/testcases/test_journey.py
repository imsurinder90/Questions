from src.journey import Journey
from src.station import Station
import pytest
from config import *


class TestJourney:

    def test_methods(self):
        """
        Test methods of class Journey
        :return: None
        """
        journeyObj = Journey()

        # Test Case 1 - Test get_cost_by_zones method
        assert journeyObj.get_cost_by_zones([1], [1], 1) == 2.5
        assert journeyObj.get_cost_by_zones([3], [1], 2) == 3.0
        assert journeyObj.get_cost_by_zones([2], [3], 2) == 2.25

        # Test Case 2 - Test get_journey_cost method
        start_station = Station.get_station_by_name("Holborn")  # Pickup point
        journeyObj.from_station(start_station, "tube")

        end_station = Station.get_station_by_name("EarlsCourt")  # Drop point
        journeyObj.to_station(end_station)
        assert journeyObj.get_journey_cost() == 2.5

        # Test Case 3
        start_station = Station.get_station_by_name("EarlsCourt")  # Pickup point
        journeyObj.from_station(start_station, "tube")

        end_station = Station.get_station_by_name("Hammersmith")  # Drop point
        journeyObj.to_station(end_station)
        assert journeyObj.get_journey_cost() == 2.0

        # Test Case 4
        start_station = Station.get_station_by_name("Hammersmith")  # Pickup point
        journeyObj.from_station(start_station, "tube")

        end_station = Station.get_station_by_name("Wimbledon")  # Drop point
        journeyObj.to_station(end_station)
        assert journeyObj.get_journey_cost() == 2.25

        # Test Case 5 - test method get_zones_crossed
        assert Journey.get_zones_crossed([1], [1]) == 1
        assert Journey.get_zones_crossed([2], [2]) == 1
        assert Journey.get_zones_crossed([3], [3]) == 1
        assert Journey.get_zones_crossed([1], [1, 2]) == 1
        assert Journey.get_zones_crossed([2], [1, 2]) == 1
        assert Journey.get_zones_crossed([3], [1, 2]) == 2

        # Negative Test Cases
        with pytest.raises(RuntimeError):
            Station.get_station_by_name("UnknownLocation")  # Pickup point

        start_station = Station.get_station_by_name("Hammersmith")  # Pickup point
        with pytest.raises(RuntimeError):
            journeyObj.from_station(start_station, "hyperloop")


