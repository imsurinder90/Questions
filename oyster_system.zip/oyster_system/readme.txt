Oyster Sytem

To run the project, setup a virtual environment and then install requiremnts by running:
>>pip install - r requirements.txt

To run the code, type of terminal:
>> python run.py

To run the test cases, type:
>> pytest -v

Thank you.