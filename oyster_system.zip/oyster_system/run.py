from src.oyster import Oyster
from src.card import FareCard
from config import *
import logging

# Create logging
log = logging.getLogger()
log.setLevel(logging.INFO)
stream_handler = logging.StreamHandler()
formatter = logging.Formatter("%(message)s")
stream_handler.setFormatter(formatter)
log.addHandler(stream_handler)


def start():
    AMOUNT_TO_CREDIT = 30
    # Issue a Fare card
    card_obj = FareCard()

    oyster_obj = Oyster()
    # Swipe fare card
    oyster_obj.swipe_card(card_obj)
    oyster_obj.recharge_card(AMOUNT_TO_CREDIT)
    log.info("Credit Fare card with amount: {}".format(AMOUNT_TO_CREDIT))

    # Took Tube from Holborn to EarlsCourt
    oyster_obj.start_journey("Holborn", "tube")
    oyster_obj.end_journey("EarlsCourt")

    # Took Bus from EarlsCourt to Chelsea
    oyster_obj.start_journey("EarlsCourt", "bus")

    # Took Tube from EarlsCourt to Hammersmith
    oyster_obj.start_journey("EarlsCourt", "tube")
    oyster_obj.end_journey("Hammersmith")


start()
