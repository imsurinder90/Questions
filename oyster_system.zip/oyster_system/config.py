"""
Config file - Define variables with values which are configurable.
"""

MAXIMUM_COST = 3.20
BUS_COST = 1.80
MINIMUM_BALANCE = 2.00

# Travelling mode
TRAVEL_MODES = ['bus', 'tube']

# Define trip cost by zones
TRAVEL_ONLY_ZONE_ONE = 2.50
TRAVEL_ONE_ZONE_EXCEPT_ZONE_ONE = 2.00
TRAVEL_TWO_ZONES_INCLUDING_ZONE_ONE = 3.00
TRAVEL_TWO_ZONES_EXCEPT_ZONE_ONE = 2.25
TRAVEL_THREE_ZONES = 3.20

# STATION TO ZONE MAPPING
STATIONS_NAME = {
    "Holborn": [1],
    "Aldgate": [1],
    "EarlsCourt": [1, 2],
    "Hammersmith": [2],
    "Arsenal": [2],
    "Wimbledon": [3]
}

# All stations
# HOLBORN = "Holborn"
# ALDGATE = "Aldgate"
# EARLSCOURT = "EarlsCourt"
# HAMMERSMITH = "Hammersmith"
# ARSENAL = "Arsenal"
# WIMBELDON = "Wimbledon"
#
# # STATION TO ZONE MAPPING
# STATIONS_NAME = {
#     HOLBORN: [1],
#     ALDGATE: [1],
#     EARLSCOURT: [1, 2],
#     HAMMERSMITH: [2],
#     ARSENAL: [2],
#     WIMBELDON: [3]
# }